"""Global context processors for EYE-FONCIER."""

from django.conf import settings


def site_context(request):
    return {
        "SITE_NAME": "EYE-FONCIER",
        "SITE_TAGLINE": "Plateforme WebSIG de Transaction Foncière Sécurisée",
        "DEBUG": settings.DEBUG,
    }
