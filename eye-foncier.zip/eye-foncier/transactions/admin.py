from django.contrib import admin
from .models import Transaction, BonDeVisite


@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = [
        "reference", "parcelle", "buyer", "seller",
        "amount", "status", "escrow_funded", "compromis_generated", "created_at",
    ]
    list_filter = ["status", "payment_method", "escrow_funded", "compromis_generated", "created_at"]
    search_fields = ["reference", "parcelle__lot_number", "buyer__email", "seller__email"]
    readonly_fields = ["reference", "created_at", "updated_at"]
    date_hierarchy = "created_at"
    fieldsets = (
        ("Transaction", {
            "fields": ("reference", "parcelle", "buyer", "seller", "amount", "status", "payment_method", "notes"),
        }),
        ("Séquestre", {
            "fields": ("escrow_funded", "escrow_amount", "escrow_funded_at", "escrow_released", "escrow_released_at", "buyer_docs_confirmed", "buyer_docs_confirmed_at"),
            "classes": ("collapse",),
        }),
        ("Compromis de vente", {
            "fields": ("compromis_generated", "compromis_generated_at", "compromis_signed_buyer", "compromis_signed_seller"),
            "classes": ("collapse",),
        }),
        ("Dates", {
            "fields": ("reserved_at", "completed_at", "cancelled_at", "created_at", "updated_at"),
        }),
    )


@admin.register(BonDeVisite)
class BonDeVisiteAdmin(admin.ModelAdmin):
    list_display = ["reference", "parcelle", "visitor", "status", "visit_date", "feedback_rating", "created_at"]
    list_filter = ["status", "created_at"]
    search_fields = ["reference", "parcelle__lot_number", "visitor__email"]
    readonly_fields = ["reference", "created_at", "updated_at"]
    date_hierarchy = "created_at"
