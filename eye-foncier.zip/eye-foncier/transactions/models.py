"""
Modèles Transactions — EYE-FONCIER
Réservation, Séquestre, Bon de Visite, Compromis de Vente.
"""
import uuid
import time
from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _
from parcelles.models import Parcelle


class Transaction(models.Model):
    """Transaction foncière (réservation → séquestre → finalisation)."""

    class Status(models.TextChoices):
        PENDING = "pending", _("En attente")
        RESERVED = "reserved", _("Réservé")
        ESCROW_FUNDED = "escrow_funded", _("Séquestre alimenté")
        DOCS_VALIDATED = "docs_validated", _("Documents validés")
        PAID = "paid", _("Payé")
        COMPLETED = "completed", _("Finalisé")
        CANCELLED = "cancelled", _("Annulé")
        DISPUTED = "disputed", _("Litige")

    class PaymentMethod(models.TextChoices):
        VIREMENT = "virement", _("Virement bancaire")
        MOBILE_MONEY = "mobile_money", _("Mobile Money")
        ESPECES = "especes", _("Espèces")
        CHEQUE = "cheque", _("Chèque")
        ESCROW = "escrow", _("Séquestre EYE-Foncier")
        AUTRE = "autre", _("Autre")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reference = models.CharField(
        _("référence"), max_length=30, unique=True, editable=False,
    )
    parcelle = models.ForeignKey(
        Parcelle, on_delete=models.PROTECT, related_name="transactions",
    )
    buyer = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
        related_name="purchases", verbose_name=_("acheteur"),
    )
    seller = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT,
        related_name="sales", verbose_name=_("vendeur"),
    )

    amount = models.DecimalField(_("montant (FCFA)"), max_digits=15, decimal_places=0)
    status = models.CharField(
        _("statut"), max_length=20, choices=Status.choices, default=Status.PENDING,
    )
    payment_method = models.CharField(
        _("mode de paiement"), max_length=20,
        choices=PaymentMethod.choices, blank=True,
    )

    notes = models.TextField(_("notes"), blank=True)
    reserved_at = models.DateTimeField(_("date de réservation"), null=True, blank=True)
    completed_at = models.DateTimeField(_("date de finalisation"), null=True, blank=True)
    cancelled_at = models.DateTimeField(_("date d'annulation"), null=True, blank=True)

    # ── Séquestre (Escrow) ──
    escrow_funded = models.BooleanField(_("séquestre alimenté"), default=False)
    escrow_amount = models.DecimalField(
        _("montant séquestre (FCFA)"), max_digits=15, decimal_places=0,
        null=True, blank=True,
    )
    escrow_funded_at = models.DateTimeField(
        _("date alimentation séquestre"), null=True, blank=True,
    )
    escrow_released = models.BooleanField(_("séquestre libéré"), default=False)
    escrow_released_at = models.DateTimeField(
        _("date libération séquestre"), null=True, blank=True,
    )
    buyer_docs_confirmed = models.BooleanField(
        _("acheteur a confirmé réception docs"), default=False,
    )
    buyer_docs_confirmed_at = models.DateTimeField(null=True, blank=True)

    # ── Compromis de vente ──
    compromis_generated = models.BooleanField(
        _("compromis généré"), default=False,
    )
    compromis_generated_at = models.DateTimeField(null=True, blank=True)
    compromis_signed_buyer = models.BooleanField(_("signé par l'acheteur"), default=False)
    compromis_signed_seller = models.BooleanField(_("signé par le vendeur"), default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Transaction")
        verbose_name_plural = _("Transactions")
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["buyer", "-created_at"]),
            models.Index(fields=["seller", "-created_at"]),
            models.Index(fields=["status"]),
        ]

    def __str__(self):
        return f"TX-{self.reference} | {self.parcelle.lot_number} | {self.get_status_display()}"

    def save(self, *args, **kwargs):
        if not self.reference:
            self.reference = f"EYF-{int(time.time())}"
        super().save(*args, **kwargs)

    @property
    def escrow_status_label(self):
        if self.escrow_released:
            return "Libéré"
        if self.buyer_docs_confirmed:
            return "Docs confirmés — En attente libération"
        if self.escrow_funded:
            return "Alimenté — En attente confirmation docs"
        return "Non alimenté"

    @property
    def progress_percent(self):
        steps = [
            self.status != self.Status.PENDING,      # Réservé
            self.escrow_funded,                       # Séquestre
            self.buyer_docs_confirmed,                # Docs OK
            self.compromis_generated,                 # Compromis
            self.status == self.Status.COMPLETED,     # Finalisé
        ]
        return int(sum(steps) / len(steps) * 100)


class BonDeVisite(models.Model):
    """Bon de visite numérique — ticket pour visiter physiquement une parcelle.

    Permet à EYE-Foncier de tracer qui visite quoi et d'assurer le suivi.
    """

    class Status(models.TextChoices):
        PENDING = "pending", _("En attente de validation")
        APPROVED = "approved", _("Approuvé")
        USED = "used", _("Utilisé — Visite effectuée")
        EXPIRED = "expired", _("Expiré")
        CANCELLED = "cancelled", _("Annulé")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    reference = models.CharField(_("référence"), max_length=30, unique=True)
    parcelle = models.ForeignKey(
        Parcelle, on_delete=models.CASCADE, related_name="bons_visite",
    )
    visitor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="bons_visite", verbose_name=_("visiteur"),
    )
    status = models.CharField(
        _("statut"), max_length=20, choices=Status.choices, default=Status.PENDING,
    )
    visit_date = models.DateTimeField(_("date de visite prévue"))
    visit_notes = models.TextField(_("notes / commentaires"), blank=True)
    feedback = models.TextField(_("retour après visite"), blank=True)
    feedback_rating = models.PositiveSmallIntegerField(
        _("note (1-5)"), null=True, blank=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Bon de visite")
        verbose_name_plural = _("Bons de visite")
        ordering = ["-created_at"]

    def __str__(self):
        return f"BV-{self.reference} | {self.parcelle.lot_number} | {self.visitor}"

    def save(self, *args, **kwargs):
        if not self.reference:
            self.reference = f"BV-{int(time.time())}"
        super().save(*args, **kwargs)
