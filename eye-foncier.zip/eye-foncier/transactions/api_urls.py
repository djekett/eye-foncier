from django.urls import path
from . import api_views

urlpatterns = [
    path("", api_views.TransactionListAPIView.as_view(), name="api_transactions"),
    path("<uuid:pk>/", api_views.TransactionDetailAPIView.as_view(), name="api_transaction_detail"),
]
