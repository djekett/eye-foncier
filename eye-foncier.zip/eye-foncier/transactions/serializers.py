from rest_framework import serializers
from .models import Transaction


class TransactionSerializer(serializers.ModelSerializer):
    buyer_name = serializers.CharField(source="buyer.get_full_name", read_only=True)
    seller_name = serializers.CharField(source="seller.get_full_name", read_only=True)
    parcelle_lot = serializers.CharField(source="parcelle.lot_number", read_only=True)
    status_display = serializers.CharField(source="get_status_display", read_only=True)

    class Meta:
        model = Transaction
        fields = [
            "id", "reference", "parcelle", "parcelle_lot",
            "buyer", "buyer_name", "seller", "seller_name",
            "amount", "status", "status_display", "payment_method",
            "notes", "reserved_at", "completed_at", "created_at",
        ]
        read_only_fields = ["id", "reference", "created_at"]
