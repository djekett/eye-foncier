from django import forms
from .models import Transaction


class ReservationForm(forms.Form):
    """Formulaire de réservation d'une parcelle."""
    notes = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            "class": "form-control",
            "rows": 3,
            "placeholder": "Message au vendeur (optionnel)...",
        }),
        label="Notes",
    )
    use_escrow = forms.BooleanField(
        required=False,
        label="Utiliser le séquestre EYE-Foncier (paiement sécurisé)",
        widget=forms.CheckboxInput(attrs={"class": "form-check-input"}),
        help_text="Les fonds sont bloqués jusqu'à réception des documents légaux.",
    )
    confirm = forms.BooleanField(
        required=True,
        label="Je confirme vouloir réserver cette parcelle",
        widget=forms.CheckboxInput(attrs={"class": "form-check-input"}),
    )


class TransactionUpdateForm(forms.ModelForm):
    """Mise à jour du statut de transaction (admin/vendeur)."""
    class Meta:
        model = Transaction
        fields = ["status", "payment_method", "notes"]
        widgets = {
            "status": forms.Select(attrs={"class": "form-select"}),
            "payment_method": forms.Select(attrs={"class": "form-select"}),
            "notes": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }
