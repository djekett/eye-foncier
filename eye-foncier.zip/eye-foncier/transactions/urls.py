from django.urls import path
from . import views

app_name = "transactions"

urlpatterns = [
    path("", views.TransactionListView.as_view(), name="list"),
    path("reserver/<uuid:parcelle_pk>/", views.reserve_parcelle_view, name="reserve"),
    path("<uuid:pk>/", views.TransactionDetailView.as_view(), name="detail"),
    path("<uuid:pk>/modifier/", views.transaction_update_view, name="update"),
    # Séquestre (Escrow)
    path("<uuid:pk>/sequestre/", views.escrow_fund_view, name="escrow_fund"),
    path("<uuid:pk>/confirmer-docs/", views.escrow_confirm_docs_view, name="escrow_confirm_docs"),
    path("<uuid:pk>/liberer/", views.escrow_release_view, name="escrow_release"),
    # Compromis
    path("<uuid:pk>/compromis/", views.initiate_compromis_view, name="compromis"),
    # Bon de visite
    path("visite/<uuid:parcelle_pk>/", views.request_visit_view, name="request_visit"),
    path("visite/detail/<uuid:pk>/", views.visit_detail_view, name="visit_detail"),
]
