from rest_framework import generics, permissions
from django.db.models import Q
from .models import Transaction
from .serializers import TransactionSerializer


class TransactionListAPIView(generics.ListAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.is_admin_role:
            return Transaction.objects.all()
        return Transaction.objects.filter(Q(buyer=user) | Q(seller=user))


class TransactionDetailAPIView(generics.RetrieveAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.is_admin_role:
            return Transaction.objects.all()
        return Transaction.objects.filter(Q(buyer=user) | Q(seller=user))
