"""Vues des transactions — réservation, séquestre, bon de visite, compromis."""
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone
from django.views.generic import ListView, DetailView
from django.http import JsonResponse

from .models import Transaction, BonDeVisite
from .forms import ReservationForm, TransactionUpdateForm
from parcelles.models import Parcelle
from accounts.models import AccessLog


@login_required
def reserve_parcelle_view(request, parcelle_pk):
    """Réservation d'une parcelle par un acheteur."""
    parcelle = get_object_or_404(Parcelle, pk=parcelle_pk)

    if not request.user.is_acheteur:
        messages.error(request, "Seuls les acheteurs peuvent réserver.")
        return redirect("parcelles:detail", pk=parcelle_pk)

    if parcelle.status != Parcelle.Status.DISPONIBLE:
        messages.warning(request, "Cette parcelle n'est plus disponible.")
        return redirect("parcelles:detail", pk=parcelle_pk)

    if request.method == "POST":
        form = ReservationForm(request.POST)
        if form.is_valid():
            use_escrow = form.cleaned_data.get("use_escrow", False)
            tx = Transaction.objects.create(
                parcelle=parcelle,
                buyer=request.user,
                seller=parcelle.owner,
                amount=parcelle.price,
                status=Transaction.Status.RESERVED,
                payment_method="escrow" if use_escrow else "",
                notes=form.cleaned_data.get("notes", ""),
                reserved_at=timezone.now(),
            )
            parcelle.status = Parcelle.Status.RESERVE
            parcelle.save()

            AccessLog.objects.create(
                user=request.user,
                action=AccessLog.ActionType.RESERVATION,
                resource_type="Parcelle",
                resource_id=str(parcelle.pk),
                details={"transaction": str(tx.pk), "amount": str(tx.amount)},
            )

            messages.success(
                request,
                f"Parcelle {parcelle.lot_number} réservée ! Référence : {tx.reference}",
            )
            return redirect("transactions:detail", pk=tx.pk)
    else:
        form = ReservationForm()

    return render(request, "transactions/reserve.html", {
        "form": form, "parcelle": parcelle,
    })


# ─── Séquestre (Escrow) ────────────────────────────────
@login_required
def escrow_fund_view(request, pk):
    """Alimenter le séquestre — l'acheteur verse les fonds."""
    tx = get_object_or_404(Transaction, pk=pk)
    if tx.buyer != request.user:
        messages.error(request, "Seul l'acheteur peut alimenter le séquestre.")
        return redirect("transactions:detail", pk=pk)
    if tx.escrow_funded:
        messages.info(request, "Le séquestre est déjà alimenté.")
        return redirect("transactions:detail", pk=pk)

    if request.method == "POST":
        tx.escrow_funded = True
        tx.escrow_amount = tx.amount
        tx.escrow_funded_at = timezone.now()
        tx.status = Transaction.Status.ESCROW_FUNDED
        tx.payment_method = "escrow"
        tx.save()
        messages.success(
            request,
            f"{tx.amount:,.0f} FCFA déposés en séquestre EYE-Foncier. "
            "Les fonds seront libérés après confirmation de réception des documents."
        )
        return redirect("transactions:detail", pk=pk)

    return render(request, "transactions/escrow_fund.html", {"transaction": tx})


@login_required
def escrow_confirm_docs_view(request, pk):
    """L'acheteur confirme avoir reçu les documents légaux."""
    tx = get_object_or_404(Transaction, pk=pk)
    if tx.buyer != request.user:
        messages.error(request, "Non autorisé.")
        return redirect("transactions:detail", pk=pk)
    if not tx.escrow_funded:
        messages.warning(request, "Le séquestre n'est pas encore alimenté.")
        return redirect("transactions:detail", pk=pk)

    if request.method == "POST":
        tx.buyer_docs_confirmed = True
        tx.buyer_docs_confirmed_at = timezone.now()
        tx.status = Transaction.Status.DOCS_VALIDATED
        tx.save()
        messages.success(
            request,
            "Réception des documents confirmée ! "
            "EYE-Foncier va procéder à la libération des fonds au vendeur."
        )
        return redirect("transactions:detail", pk=pk)

    return render(request, "transactions/escrow_confirm.html", {"transaction": tx})


@login_required
def escrow_release_view(request, pk):
    """Admin/EYE-Foncier libère le séquestre vers le vendeur."""
    tx = get_object_or_404(Transaction, pk=pk)
    if not (request.user.is_admin_role or request.user.is_superuser):
        messages.error(request, "Seul un administrateur peut libérer le séquestre.")
        return redirect("transactions:detail", pk=pk)

    if request.method == "POST":
        tx.escrow_released = True
        tx.escrow_released_at = timezone.now()
        tx.status = Transaction.Status.COMPLETED
        tx.completed_at = timezone.now()
        tx.parcelle.status = Parcelle.Status.VENDU
        tx.parcelle.save()
        tx.save()
        messages.success(request, f"Séquestre libéré — {tx.amount:,.0f} FCFA transférés au vendeur.")
        return redirect("transactions:detail", pk=pk)

    return render(request, "transactions/escrow_release.html", {"transaction": tx})


# ─── Compromis de vente ─────────────────────────────────
@login_required
def initiate_compromis_view(request, pk):
    """Initier la vente — génère un compromis pré-rempli."""
    tx = get_object_or_404(Transaction, pk=pk)
    if tx.seller != request.user and not request.user.is_admin_role:
        messages.error(request, "Seul le vendeur ou un admin peut initier la vente.")
        return redirect("transactions:detail", pk=pk)

    if request.method == "POST":
        tx.compromis_generated = True
        tx.compromis_generated_at = timezone.now()
        tx.save()
        messages.success(
            request,
            "Compromis de vente généré ! EYE-Foncier a reçu une alerte prioritaire. "
            "Les deux parties seront contactées pour signature."
        )
        return redirect("transactions:detail", pk=pk)

    return render(request, "transactions/compromis.html", {"transaction": tx})


# ─── Bon de Visite ──────────────────────────────────────
@login_required
def request_visit_view(request, parcelle_pk):
    """Générer un bon de visite pour une parcelle."""
    parcelle = get_object_or_404(Parcelle, pk=parcelle_pk)

    if not request.user.is_acheteur:
        messages.error(request, "Seuls les acheteurs peuvent demander une visite.")
        return redirect("parcelles:detail", pk=parcelle_pk)

    if request.method == "POST":
        visit_date_str = request.POST.get("visit_date", "")
        visit_notes = request.POST.get("visit_notes", "")

        if not visit_date_str:
            messages.error(request, "Veuillez indiquer une date de visite.")
            return redirect("transactions:request_visit", parcelle_pk=parcelle_pk)

        from django.utils.dateparse import parse_datetime
        visit_date = parse_datetime(visit_date_str + "T09:00:00") or timezone.now()

        bon = BonDeVisite.objects.create(
            parcelle=parcelle,
            visitor=request.user,
            visit_date=visit_date,
            visit_notes=visit_notes,
        )

        AccessLog.objects.create(
            user=request.user,
            action=AccessLog.ActionType.VIEW_PARCELLE,
            resource_type="BonDeVisite",
            resource_id=str(bon.pk),
            details={"parcelle": str(parcelle.pk), "date": visit_date_str},
        )

        messages.success(
            request,
            f"Bon de visite généré ! Référence : {bon.reference}. "
            "Le vendeur sera notifié de votre visite."
        )
        return redirect("transactions:visit_detail", pk=bon.pk)

    return render(request, "transactions/request_visit.html", {"parcelle": parcelle})


@login_required
def visit_detail_view(request, pk):
    """Détail d'un bon de visite (+ feedback après visite)."""
    bon = get_object_or_404(BonDeVisite, pk=pk)
    if bon.visitor != request.user and bon.parcelle.owner != request.user and not request.user.is_admin_role:
        messages.error(request, "Non autorisé.")
        return redirect("transactions:list")

    if request.method == "POST" and bon.visitor == request.user:
        # Soumettre le feedback post-visite
        bon.feedback = request.POST.get("feedback", "")
        rating = request.POST.get("rating")
        if rating and rating.isdigit():
            bon.feedback_rating = min(5, max(1, int(rating)))
        bon.status = BonDeVisite.Status.USED
        bon.save()
        messages.success(request, "Merci pour votre retour !")
        return redirect("transactions:visit_detail", pk=pk)

    return render(request, "transactions/visit_detail.html", {"bon": bon})


class TransactionDetailView(LoginRequiredMixin, DetailView):
    model = Transaction
    template_name = "transactions/transaction_detail.html"
    context_object_name = "transaction"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user
        tx = self.object
        ctx["can_update"] = (tx.seller == user or user.is_staff or user.is_admin_role)
        ctx["is_buyer"] = (tx.buyer == user)
        ctx["is_seller"] = (tx.seller == user)
        ctx["is_admin"] = (user.is_admin_role or user.is_superuser)
        return ctx


class TransactionListView(LoginRequiredMixin, ListView):
    model = Transaction
    template_name = "transactions/transaction_list.html"
    context_object_name = "transactions"
    paginate_by = 20

    def get_queryset(self):
        user = self.request.user
        if user.is_staff or user.is_admin_role:
            return Transaction.objects.all().select_related("parcelle", "buyer", "seller")
        return Transaction.objects.filter(
            Q(buyer=user) | Q(seller=user)
        ).select_related("parcelle", "buyer", "seller")


@login_required
def transaction_update_view(request, pk):
    """Mise à jour d'une transaction."""
    tx = get_object_or_404(Transaction, pk=pk)
    if tx.seller != request.user and not request.user.is_admin_role:
        messages.error(request, "Non autorisé.")
        return redirect("transactions:detail", pk=pk)

    if request.method == "POST":
        form = TransactionUpdateForm(request.POST, instance=tx)
        if form.is_valid():
            transaction = form.save(commit=False)
            if transaction.status == Transaction.Status.COMPLETED:
                transaction.completed_at = timezone.now()
                transaction.parcelle.status = Parcelle.Status.VENDU
                transaction.parcelle.save()
            elif transaction.status == Transaction.Status.CANCELLED:
                transaction.cancelled_at = timezone.now()
                transaction.parcelle.status = Parcelle.Status.DISPONIBLE
                transaction.parcelle.save()
            transaction.save()
            messages.success(request, "Transaction mise à jour.")
            return redirect("transactions:detail", pk=pk)
    else:
        form = TransactionUpdateForm(instance=tx)

    return render(request, "transactions/transaction_update.html", {
        "form": form, "transaction": tx,
    })
