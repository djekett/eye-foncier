"""Vues de gestion des parcelles."""
import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.contrib import messages
from django.views.generic import ListView, DetailView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.db.models import Q
from django.http import JsonResponse
from django.core.serializers import serialize

from .models import Parcelle, ParcelleMedia, Zone
from .forms import ParcelleForm, ParcelleMediaForm, ParcelleSearchForm
from accounts.models import AccessLog


class ParcelleListView(ListView):
    """Liste des parcelles avec filtrage."""
    model = Parcelle
    template_name = "parcelles/parcelle_list.html"
    context_object_name = "parcelles"
    paginate_by = 12

    def get_queryset(self):
        user = self.request.user
        qs = Parcelle.objects.select_related("owner", "zone")

        # Admin/staff voient tout, vendeur voit ses propres parcelles non validées
        if user.is_authenticated and (user.is_admin_role or user.is_staff):
            pass  # Voir tout
        elif user.is_authenticated and user.is_vendeur:
            qs = qs.filter(Q(is_validated=True) | Q(owner=user))
        else:
            qs = qs.filter(is_validated=True)

        form = ParcelleSearchForm(self.request.GET)

        if form.is_valid():
            q = form.cleaned_data.get("q")
            if q:
                qs = qs.filter(
                    Q(title__icontains=q) | Q(lot_number__icontains=q) |
                    Q(address__icontains=q) | Q(description__icontains=q)
                )
            if form.cleaned_data.get("status"):
                qs = qs.filter(status=form.cleaned_data["status"])
            if form.cleaned_data.get("land_type"):
                qs = qs.filter(land_type=form.cleaned_data["land_type"])
            if form.cleaned_data.get("price_min"):
                qs = qs.filter(price__gte=form.cleaned_data["price_min"])
            if form.cleaned_data.get("price_max"):
                qs = qs.filter(price__lte=form.cleaned_data["price_max"])
            if form.cleaned_data.get("surface_min"):
                qs = qs.filter(surface_m2__gte=form.cleaned_data["surface_min"])
            if form.cleaned_data.get("surface_max"):
                qs = qs.filter(surface_m2__lte=form.cleaned_data["surface_max"])
            if form.cleaned_data.get("zone"):
                qs = qs.filter(zone_id=form.cleaned_data["zone"])

        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["form"] = ParcelleSearchForm(self.request.GET)
        ctx["zones"] = Zone.objects.all()
        ctx["total"] = self.get_queryset().count()
        return ctx


class ParcelleDetailView(DetailView):
    """Détail d'une parcelle avec médias, bons de visite, certification."""
    model = Parcelle
    template_name = "parcelles/parcelle_detail.html"
    context_object_name = "parcelle"

    def get_queryset(self):
        return Parcelle.objects.select_related("owner", "owner__profile", "zone", "ilot")

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        parcelle = self.object
        user = self.request.user
        ctx["medias"] = parcelle.medias.all()
        ctx["is_owner"] = user.is_authenticated and (parcelle.owner == user or user.is_staff)

        # Documents visibles selon le rôle
        if user.is_authenticated:
            if user.is_staff or user == parcelle.owner:
                ctx["documents"] = parcelle.documents.all()
            elif user.is_acheteur:
                ctx["documents"] = parcelle.documents.filter(
                    confidentiality__in=["public", "buyer_only"]
                )
            else:
                ctx["documents"] = parcelle.documents.filter(confidentiality="public")
        else:
            ctx["documents"] = parcelle.documents.filter(confidentiality="public")

        # Bons de visite (acheteur connecté)
        if user.is_authenticated and user.is_acheteur:
            from transactions.models import BonDeVisite
            ctx["user_visits"] = BonDeVisite.objects.filter(
                visitor=user, parcelle=parcelle
            ).order_by("-created_at")[:3]
            ctx["can_visit"] = parcelle.status == "disponible"
        else:
            ctx["user_visits"] = []
            ctx["can_visit"] = False

        # Badge certification du vendeur
        if parcelle.owner:
            from accounts.models import CertificationRequest
            cert = CertificationRequest.objects.filter(
                user=parcelle.owner, status="approved"
            ).first()
            ctx["seller_certified"] = cert is not None
        else:
            ctx["seller_certified"] = False

        # Incrémenter les vues
        Parcelle.objects.filter(pk=parcelle.pk).update(views_count=parcelle.views_count + 1)

        # Log d'accès
        if user.is_authenticated:
            AccessLog.objects.create(
                user=user,
                action=AccessLog.ActionType.VIEW_PARCELLE,
                resource_type="Parcelle",
                resource_id=str(parcelle.pk),
                ip_address=_get_ip(self.request),
            )

        return ctx


@login_required
def parcelle_create_view(request):
    """Création d'une parcelle (SuperUser uniquement)."""
    if not request.user.is_superuser:
        messages.error(request, "Seuls les SuperUtilisateurs peuvent déposer des parcelles.")
        return redirect("parcelles:list")

    if request.method == "POST":
        form = ParcelleForm(request.POST, request.FILES)
        if form.is_valid():
            parcelle = form.save(commit=False)
            parcelle.owner = request.user
            # Auto-validation pour les superusers
            parcelle.is_validated = True
            parcelle.validated_by = request.user
            from django.utils import timezone
            parcelle.validated_at = timezone.now()
            parcelle.save()
            messages.success(
                request,
                f"Parcelle « {parcelle.title} » créée avec succès ! "
                "Elle est maintenant visible sur la carte."
            )
            # Rediriger vers la carte focalisée sur la nouvelle parcelle
            return redirect(f"/carte/?focus={parcelle.pk}")
    else:
        form = ParcelleForm()

    return render(request, "parcelles/parcelle_form.html", {
        "form": form,
        "title": "Déposer une parcelle",
    })


@login_required
def parcelle_edit_view(request, pk):
    """Modification d'une parcelle par son propriétaire."""
    parcelle = get_object_or_404(Parcelle, pk=pk)
    if parcelle.owner != request.user and not request.user.is_superuser:
        messages.error(request, "Vous n'êtes pas autorisé à modifier cette parcelle.")
        return redirect("parcelles:detail", pk=pk)

    if request.method == "POST":
        form = ParcelleForm(request.POST, request.FILES, instance=parcelle)
        if form.is_valid():
            form.save()
            messages.success(request, "Parcelle mise à jour.")
            return redirect("parcelles:detail", pk=pk)
    else:
        form = ParcelleForm(instance=parcelle)

    return render(request, "parcelles/parcelle_form.html", {
        "form": form,
        "parcelle": parcelle,
        "title": "Modifier la parcelle",
    })


@login_required
def media_upload_view(request, pk):
    """Upload de médias sur une parcelle."""
    parcelle = get_object_or_404(Parcelle, pk=pk)
    if parcelle.owner != request.user and not request.user.is_admin_role:
        messages.error(request, "Non autorisé.")
        return redirect("parcelles:detail", pk=pk)

    if request.method == "POST":
        form = ParcelleMediaForm(request.POST, request.FILES)
        if form.is_valid():
            media = form.save(commit=False)
            media.parcelle = parcelle
            media.save()
            messages.success(request, "Média ajouté avec succès.")
            return redirect("parcelles:detail", pk=pk)
    else:
        form = ParcelleMediaForm()

    return render(request, "parcelles/media_upload.html", {
        "form": form,
        "parcelle": parcelle,
        "medias": parcelle.medias.all(),
    })


# ─── Validation Géomètre ───────────────────────────────
@login_required
def validate_parcelle_view(request, pk):
    """Validation technique d'une parcelle par un géomètre."""
    if not (request.user.is_geometre or request.user.is_admin_role):
        messages.error(request, "Réservé aux géomètres et administrateurs.")
        return redirect("parcelles:detail", pk=pk)

    parcelle = get_object_or_404(Parcelle, pk=pk)

    if request.method == "POST":
        from django.utils import timezone
        parcelle.is_validated = True
        parcelle.validated_by = request.user
        parcelle.validated_at = timezone.now()
        parcelle.save()
        messages.success(request, f"Parcelle {parcelle.lot_number} validée avec succès.")
        return redirect("accounts:dashboard")

    return render(request, "parcelles/validate.html", {"parcelle": parcelle})


# ─── Suppression ───────────────────────────────────────
class ParcelleDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Parcelle
    template_name = "parcelles/parcelle_confirm_delete.html"
    success_url = reverse_lazy("accounts:dashboard")

    def test_func(self):
        parcelle = self.get_object()
        return parcelle.owner == self.request.user or self.request.user.is_admin_role


def _get_ip(request):
    x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    return x_forwarded.split(",")[0].strip() if x_forwarded else request.META.get("REMOTE_ADDR")
