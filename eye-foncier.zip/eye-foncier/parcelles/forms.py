"""Formulaires de gestion des parcelles."""
from django import forms
from django.contrib.gis.geos import GEOSGeometry, Polygon
from django.core.exceptions import ValidationError
import json
import os
import tempfile
import zipfile
import logging

from .models import Parcelle, ParcelleMedia

logger = logging.getLogger("parcelles")


class ParcelleForm(forms.ModelForm):
    """Formulaire de création / modification d'une parcelle."""

    geometry_json = forms.CharField(
        widget=forms.HiddenInput(),
        required=False,
        help_text="GeoJSON de la géométrie (rempli automatiquement par la carte).",
    )

    # ─── Coordonnées textuelles (N sommets, format JSON) ───
    coordinates_text = forms.CharField(
        widget=forms.HiddenInput(),
        required=False,
        help_text="JSON array de coordonnées [[lng,lat], ...]",
    )

    # ─── Import Shapefile ────────────────────────
    shapefile_zip = forms.FileField(
        required=False,
        widget=forms.ClearableFileInput(attrs={
            "class": "form-control",
            "accept": ".zip,.shp",
        }),
        help_text="Archive .zip contenant les fichiers .shp, .shx, .dbf (et optionnellement .prj).",
    )

    class Meta:
        model = Parcelle
        fields = [
            "title", "lot_number", "description", "land_type",
            "surface_m2", "price", "address", "title_holder_name",
            "zone", "ilot", "geometry_json",
        ]
        widgets = {
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "lot_number": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 4}),
            "land_type": forms.Select(attrs={"class": "form-select"}),
            "surface_m2": forms.NumberInput(attrs={"class": "form-control", "step": "0.01"}),
            "price": forms.NumberInput(attrs={"class": "form-control"}),
            "address": forms.TextInput(attrs={"class": "form-control"}),
            "title_holder_name": forms.TextInput(attrs={"class": "form-control"}),
            "zone": forms.Select(attrs={"class": "form-select"}),
            "ilot": forms.Select(attrs={"class": "form-select"}),
        }

    def clean_geometry_json(self):
        geojson = self.cleaned_data.get("geometry_json")
        if geojson:
            try:
                geom = GEOSGeometry(geojson, srid=4326)
                if geom.geom_type not in ("Polygon", "MultiPolygon"):
                    raise forms.ValidationError("La géométrie doit être un polygone.")
                if geom.geom_type == "MultiPolygon":
                    # Prendre le premier polygone
                    geom = geom[0]
                return geom
            except forms.ValidationError:
                raise
            except Exception as e:
                raise forms.ValidationError(f"GeoJSON invalide : {e}")
        return None

    def _build_polygon_from_coordinates_text(self):
        """Construit un polygone à partir du champ coordinates_text (N sommets)."""
        raw = self.cleaned_data.get("coordinates_text", "").strip()
        if not raw:
            return None

        try:
            coords = json.loads(raw)
            if not isinstance(coords, list) or len(coords) < 3:
                return None

            # Valider chaque coordonnée
            validated = []
            for pt in coords:
                if isinstance(pt, (list, tuple)) and len(pt) >= 2:
                    lng, lat = float(pt[0]), float(pt[1])
                    validated.append((lng, lat))

            if len(validated) < 3:
                return None

            # Fermer le polygone si nécessaire
            if validated[0] != validated[-1]:
                validated.append(validated[0])

            poly = Polygon(validated, srid=4326)
            if not poly.valid:
                logger.warning(f"Polygone invalide depuis coordonnées, tentative make_valid")
                poly = poly.buffer(0)
                if hasattr(poly, 'geom_type') and poly.geom_type == 'Polygon':
                    return poly
                return None
            return poly
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            logger.error(f"Erreur parsing coordonnées textuelles: {e}")
            return None

    def _parse_shapefile(self):
        """Extrait la géométrie et les attributs d'un Shapefile uploadé."""
        shp_file = self.cleaned_data.get("shapefile_zip")
        if not shp_file:
            return None, {}

        tmpdir = None
        try:
            import fiona
            from shapely.geometry import shape, mapping
            from django.contrib.gis.geos import GEOSGeometry

            tmpdir = tempfile.mkdtemp(prefix="eyefoncier_shp_")

            # Sauvegarder le fichier uploadé
            safe_name = shp_file.name.replace(" ", "_")
            tmp_path = os.path.join(tmpdir, safe_name)
            with open(tmp_path, "wb") as f:
                for chunk in shp_file.chunks():
                    f.write(chunk)

            # ─── Déterminer comment ouvrir le fichier ───
            shp_open_path = None

            if zipfile.is_zipfile(tmp_path):
                # Méthode 1 : fiona avec protocole zip:// (GDAL VFS)
                try:
                    with zipfile.ZipFile(tmp_path, "r") as zf:
                        shp_names = [n for n in zf.namelist()
                                     if n.lower().endswith(".shp") and not os.path.basename(n).startswith(".")]
                        if not shp_names:
                            logger.error("Aucun .shp dans le zip")
                            return None, {}

                    # Normaliser le chemin (Windows → forward slashes)
                    normalized_path = tmp_path.replace("\\", "/")
                    # Windows : C:/... → /C:/... pour que zip:// ait 3 slashes
                    if len(normalized_path) >= 2 and normalized_path[1] == ":":
                        normalized_path = "/" + normalized_path
                    # Toujours spécifier le nom du .shp après !
                    shp_open_path = f"zip://{normalized_path}!{shp_names[0]}"

                except Exception as e:
                    logger.warning(f"zip:// échoué, fallback extraction: {e}")
                    # Méthode 2 (fallback) : extraire manuellement
                    shp_open_path = None
                    try:
                        with zipfile.ZipFile(tmp_path, "r") as zf:
                            zf.extractall(tmpdir)
                        for root, dirs, files in os.walk(tmpdir):
                            for fname in files:
                                if fname.lower().endswith(".shp") and not fname.startswith("."):
                                    shp_open_path = os.path.join(root, fname)
                                    break
                            if shp_open_path:
                                break
                    except Exception as e2:
                        logger.error(f"Extraction fallback échouée: {e2}")
                        return None, {}

            elif tmp_path.lower().endswith(".shp"):
                shp_open_path = tmp_path
            else:
                logger.error(f"Format non reconnu: {safe_name}")
                return None, {}

            if not shp_open_path:
                return None, {}

            # ─── Lire avec fiona ───
            attributes = {}
            geometry = None

            logger.info(f"Ouverture fiona: {shp_open_path}")

            try:
                src_handle = fiona.open(shp_open_path)
            except Exception as e_open:
                logger.warning(f"fiona.open({shp_open_path}) échoué: {e_open}")
                # Fallback : extraire le zip et ouvrir le .shp directement
                if zipfile.is_zipfile(tmp_path):
                    try:
                        with zipfile.ZipFile(tmp_path, "r") as zf:
                            zf.extractall(tmpdir)
                        for root, dirs, files in os.walk(tmpdir):
                            for fname in files:
                                if fname.lower().endswith(".shp") and not fname.startswith("."):
                                    extracted_path = os.path.join(root, fname)
                                    logger.info(f"Fallback: ouverture {extracted_path}")
                                    src_handle = fiona.open(extracted_path)
                                    break
                            if 'src_handle' in dir():
                                break
                        else:
                            return None, {}
                    except Exception as e_fallback:
                        logger.error(f"Fallback extraction échoué: {e_fallback}")
                        return None, {}
                else:
                    return None, {}

            with src_handle as src:
                # Détecter le CRS et préparer la reprojection
                src_crs = src.crs
                reproject_func = None

                if src_crs:
                    crs_str = str(src_crs).lower()
                    if "4326" not in crs_str and "wgs" not in crs_str:
                        try:
                            import pyproj
                            from shapely.ops import transform as shapely_transform
                            transformer = pyproj.Transformer.from_crs(
                                src_crs, "EPSG:4326", always_xy=True
                            )
                            reproject_func = transformer.transform
                        except ImportError:
                            logger.warning("pyproj non installé — pas de reprojection")
                        except Exception as e:
                            logger.warning(f"Erreur init reprojection: {e}")

                for feature in src:
                    geom = shape(feature["geometry"])

                    # Reprojeter si nécessaire
                    if reproject_func:
                        from shapely.ops import transform as shapely_transform
                        geom = shapely_transform(reproject_func, geom)

                    if geom.geom_type in ("Polygon", "MultiPolygon"):
                        if geom.geom_type == "MultiPolygon":
                            geom = list(geom.geoms)[0]

                        geojson_str = json.dumps(mapping(geom))
                        geometry = GEOSGeometry(geojson_str, srid=4326)
                        attributes = {}
                        # Convertir les propriétés en dict propre
                        raw_props = feature.get("properties", {})
                        if raw_props:
                            for k, v in raw_props.items():
                                if v is not None:
                                    attributes[k] = v
                        break

            return geometry, attributes

        except Exception as e:
            logger.error(f"Erreur lecture Shapefile: {e}", exc_info=True)
            return None, {}
        finally:
            # Nettoyage
            if tmpdir:
                import shutil
                shutil.rmtree(tmpdir, ignore_errors=True)

    def clean(self):
        cleaned = super().clean()
        geom = cleaned.get("geometry_json")

        # Priorité 1 : geometry_json (dessin sur carte ou pré-rempli par JS)
        if geom:
            return cleaned

        # Priorité 2 : coordonnées textuelles (N sommets)
        poly = self._build_polygon_from_coordinates_text()
        if poly:
            cleaned["geometry_json"] = poly
            return cleaned

        # Priorité 3 : Shapefile
        shp_geom, shp_attrs = self._parse_shapefile()
        if shp_geom:
            cleaned["geometry_json"] = shp_geom
            self._shp_attributes = shp_attrs
            return cleaned

        # Aucune géométrie fournie
        if not self.instance.pk or not self.instance.geometry:
            self.add_error(
                None,
                "Veuillez fournir une géométrie : dessinez sur la carte, "
                "saisissez les coordonnées, ou importez un Shapefile."
            )

        return cleaned

    def save(self, commit=True):
        instance = super().save(commit=False)
        geom = self.cleaned_data.get("geometry_json")
        if geom:
            instance.geometry = geom

        # Auto-remplir depuis les attributs Shapefile si disponibles
        shp_attrs = getattr(self, "_shp_attributes", {})
        if shp_attrs:
            field_mapping = {
                "title": ["TITRE", "TITLE", "NOM", "NAME", "LIBELLE", "LABEL"],
                "lot_number": ["LOT", "LOT_NUM", "NUMERO", "NUM_LOT", "LOT_NUMBER", "NUM"],
                "address": ["ADRESSE", "ADDRESS", "ADDR", "LIEU", "LOCALITE"],
                "description": ["DESC", "DESCRIPTION", "COMMENTAIRE", "COMMENT", "NOTES"],
            }
            for model_field, shp_keys in field_mapping.items():
                if not getattr(instance, model_field, None):
                    for key in shp_keys:
                        val = shp_attrs.get(key) or shp_attrs.get(key.lower())
                        if val:
                            setattr(instance, model_field, str(val))
                            break

            # Surface depuis attributs
            if not instance.surface_m2 or instance.surface_m2 == 0:
                for key in ["SURFACE", "SUPERFICIE", "AREA", "SURF_M2", "surface"]:
                    val = shp_attrs.get(key) or shp_attrs.get(key.lower())
                    if val:
                        try:
                            instance.surface_m2 = float(val)
                        except (ValueError, TypeError):
                            pass
                        break

        if commit:
            instance.save()
        return instance


class ParcelleMediaForm(forms.ModelForm):
    """Upload de médias pour une parcelle."""

    class Meta:
        model = ParcelleMedia
        fields = ["media_type", "title", "file"]
        widgets = {
            "media_type": forms.Select(attrs={"class": "form-select"}),
            "title": forms.TextInput(attrs={"class": "form-control"}),
            "file": forms.ClearableFileInput(attrs={"class": "form-control"}),
        }


class ParcelleSearchForm(forms.Form):
    """Formulaire de recherche / filtrage des parcelles."""
    q = forms.CharField(required=False, widget=forms.TextInput(
        attrs={"class": "form-control", "placeholder": "Rechercher..."}
    ))
    zone = forms.UUIDField(required=False, widget=forms.HiddenInput())
    status = forms.ChoiceField(
        required=False,
        choices=[("", "Tous")] + list(Parcelle.Status.choices),
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    land_type = forms.ChoiceField(
        required=False,
        choices=[("", "Tous")] + list(Parcelle.LandType.choices),
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    price_min = forms.DecimalField(
        required=False, widget=forms.NumberInput(
            attrs={"class": "form-control", "placeholder": "Prix min"}
        ),
    )
    price_max = forms.DecimalField(
        required=False, widget=forms.NumberInput(
            attrs={"class": "form-control", "placeholder": "Prix max"}
        ),
    )
    surface_min = forms.DecimalField(
        required=False, widget=forms.NumberInput(
            attrs={"class": "form-control", "placeholder": "Surface min (m²)"}
        ),
    )
    surface_max = forms.DecimalField(
        required=False, widget=forms.NumberInput(
            attrs={"class": "form-control", "placeholder": "Surface max (m²)"}
        ),
    )
