from django.contrib.gis import admin
from .models import Zone, Ilot, Parcelle, ParcelleMedia


@admin.register(Zone)
class ZoneAdmin(admin.GISModelAdmin):
    list_display = ["name", "code", "created_at"]
    search_fields = ["name", "code"]


@admin.register(Ilot)
class IlotAdmin(admin.GISModelAdmin):
    list_display = ["code", "name", "zone", "created_at"]
    list_filter = ["zone"]
    search_fields = ["code", "name"]


class ParcelleMediaInline(admin.TabularInline):
    model = ParcelleMedia
    extra = 0


@admin.register(Parcelle)
class ParcelleAdmin(admin.GISModelAdmin):
    inlines = [ParcelleMediaInline]
    list_display = [
        "lot_number", "title", "owner", "status", "price",
        "surface_m2", "is_validated", "trust_badge", "created_at",
    ]
    list_filter = ["status", "land_type", "is_validated", "trust_badge", "zone"]
    search_fields = ["lot_number", "title", "address", "owner__email"]
    readonly_fields = ["centroid", "price_per_m2", "views_count", "trust_badge"]
    date_hierarchy = "created_at"
    fieldsets = (
        ("Identification", {"fields": ("lot_number", "title", "description", "owner")}),
        ("Localisation", {"fields": ("zone", "ilot", "address", "geometry", "centroid")}),
        ("Caractéristiques", {"fields": ("land_type", "surface_m2", "price", "price_per_m2")}),
        ("Statut", {"fields": ("status", "is_validated", "validated_by", "validated_at")}),
        ("Confiance", {"fields": ("title_holder_name", "trust_badge")}),
        ("Stats", {"fields": ("views_count",)}),
    )


@admin.register(ParcelleMedia)
class ParcelleMediaAdmin(admin.ModelAdmin):
    list_display = ["parcelle", "media_type", "title", "order", "created_at"]
    list_filter = ["media_type"]
