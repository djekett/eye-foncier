"""Vues API GIS pour les parcelles."""
import json
import logging
import os
import shutil
import tempfile
import zipfile

from rest_framework import generics, permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework_gis.filters import InBBOXFilter
from django_filters.rest_framework import DjangoFilterBackend
from django.contrib.gis.geos import Point
from django.contrib.gis.measure import D
from django.db.models import Q

from .models import Parcelle, Zone, Ilot
from .serializers import (
    ParcelleListSerializer,
    ParcelleDetailSerializer,
    ZoneSerializer,
    IlotSerializer,
)

logger = logging.getLogger("parcelles")


class ParcelleGeoListView(generics.ListAPIView):
    """Liste GeoJSON des parcelles pour la carte.

    IMPORTANT : pagination_class = None
    La pagination DRF globale (PageNumberPagination) enveloppait la réponse
    dans {"count":..., "results": {FeatureCollection}} au lieu de retourner
    le FeatureCollection brut. Le JS attend data.features directement.
    """
    serializer_class = ParcelleListSerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = None  # ← FIX CRITIQUE : GeoJSON ne doit PAS être paginé
    filter_backends = [DjangoFilterBackend, InBBOXFilter]
    bbox_filter_field = "geometry"
    filterset_fields = ["status", "land_type", "zone", "is_validated"]

    def get_queryset(self):
        qs = Parcelle.objects.select_related("owner", "zone").filter(
            is_validated=True,
            geometry__isnull=False,
        )

        # Recherche textuelle
        search = self.request.query_params.get("search")
        if search:
            qs = qs.filter(
                Q(title__icontains=search) |
                Q(lot_number__icontains=search) |
                Q(address__icontains=search) |
                Q(description__icontains=search) |
                Q(zone__name__icontains=search)
            )

        # Filtre par prix
        price_min = self.request.query_params.get("price_min")
        price_max = self.request.query_params.get("price_max")
        if price_min:
            qs = qs.filter(price__gte=price_min)
        if price_max:
            qs = qs.filter(price__lte=price_max)

        # Filtre par surface
        surface_min = self.request.query_params.get("surface_min")
        surface_max = self.request.query_params.get("surface_max")
        if surface_min:
            qs = qs.filter(surface_m2__gte=surface_min)
        if surface_max:
            qs = qs.filter(surface_m2__lte=surface_max)

        return qs

    def get_serializer_context(self):
        ctx = super().get_serializer_context()
        ctx["request"] = self.request
        return ctx

    def list(self, request, *args, **kwargs):
        """Override list : no-cache + safety net."""
        try:
            response = super().list(request, *args, **kwargs)
        except Exception as e:
            logger.error(f"Erreur API GeoJSON list: {e}", exc_info=True)
            response = Response({
                "type": "FeatureCollection",
                "features": [],
                "_error": str(e),
            })
        # Empêcher tout cache navigateur/proxy
        response["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response["Pragma"] = "no-cache"
        return response


class ParcelleGeoDetailView(generics.RetrieveAPIView):
    """Détail GeoJSON d'une parcelle."""
    serializer_class = ParcelleDetailSerializer
    permission_classes = [permissions.AllowAny]
    queryset = Parcelle.objects.select_related("owner", "owner__profile", "zone", "ilot")


@api_view(["GET"])
@permission_classes([permissions.AllowAny])
def nearby_parcelles(request):
    """Parcelles dans un rayon donné autour d'un point (lat, lng, radius_km)."""
    try:
        lat = float(request.query_params.get("lat"))
        lng = float(request.query_params.get("lng"))
        radius = float(request.query_params.get("radius", 5))  # km
    except (TypeError, ValueError):
        return Response(
            {"error": "Paramètres lat, lng requis (radius optionnel, défaut 5km)."},
            status=status.HTTP_400_BAD_REQUEST,
        )

    point = Point(lng, lat, srid=4326)
    parcelles = Parcelle.objects.filter(
        geometry__distance_lte=(point, D(km=radius)),
        is_validated=True,
    ).select_related("owner", "zone")

    serializer = ParcelleListSerializer(parcelles, many=True, context={"request": request})
    return Response(serializer.data)


class ZoneListView(generics.ListAPIView):
    """Liste des zones (GeoJSON)."""
    serializer_class = ZoneSerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = None
    queryset = Zone.objects.all()


class IlotListView(generics.ListAPIView):
    """Liste des îlots (GeoJSON)."""
    serializer_class = IlotSerializer
    permission_classes = [permissions.AllowAny]
    pagination_class = None
    queryset = Ilot.objects.all()

    def get_queryset(self):
        qs = super().get_queryset()
        zone = self.request.query_params.get("zone")
        if zone:
            qs = qs.filter(zone_id=zone)
        return qs


def _open_shapefile_fiona(file_path):
    """
    Ouvre un shapefile (zip ou .shp direct) avec fiona.
    Gère les chemins Windows et le protocole zip://.
    Retourne un tuple (features_list, crs_info_string).
    """
    import fiona
    from shapely.geometry import shape, mapping

    open_path = None
    is_zip = False

    try:
        is_zip = zipfile.is_zipfile(file_path)
    except Exception:
        is_zip = False

    if is_zip:
        # Trouver le .shp dans le zip
        shp_name_in_zip = None
        try:
            with zipfile.ZipFile(file_path, "r") as zf:
                for name in zf.namelist():
                    if name.lower().endswith(".shp") and not os.path.basename(name).startswith("."):
                        shp_name_in_zip = name
                        break
        except Exception as e:
            raise ValueError(f"Impossible de lire le fichier zip : {e}")

        if not shp_name_in_zip:
            raise ValueError("Aucun fichier .shp trouvé dans l'archive zip.")

        # Normaliser le chemin pour GDAL (forward slashes)
        normalized = file_path.replace("\\", "/")
        # Windows : C:/... → /C:/... pour que zip:// ait 3 slashes
        if len(normalized) >= 2 and normalized[1] == ":":
            normalized = "/" + normalized
        # Toujours spécifier le .shp après !
        open_path = f"zip://{normalized}!{shp_name_in_zip}"

    elif file_path.lower().endswith(".shp"):
        open_path = file_path
    else:
        raise ValueError(f"Format de fichier non supporté: {os.path.basename(file_path)}")

    # Ouvrir avec fiona (avec fallback extraction)
    features = []
    crs_info = "Non défini"

    try:
        src_handle = fiona.open(open_path)
    except Exception as e_open:
        logger.warning(f"fiona.open({open_path}) échoué: {e_open}, tentative extraction...")
        if is_zip:
            # Fallback : extraire et ouvrir le .shp directement
            extract_dir = tempfile.mkdtemp(prefix="eyefoncier_extract_")
            try:
                with zipfile.ZipFile(file_path, "r") as zf:
                    zf.extractall(extract_dir)
                extracted_shp = None
                for root, dirs, files in os.walk(extract_dir):
                    for fname in files:
                        if fname.lower().endswith(".shp") and not fname.startswith("."):
                            extracted_shp = os.path.join(root, fname)
                            break
                    if extracted_shp:
                        break
                if not extracted_shp:
                    raise ValueError("Aucun .shp trouvé après extraction")
                src_handle = fiona.open(extracted_shp)
            except Exception as e_fallback:
                shutil.rmtree(extract_dir, ignore_errors=True)
                raise ValueError(f"Impossible d'ouvrir le shapefile : {e_fallback}")
        else:
            raise ValueError(f"Impossible d'ouvrir le fichier : {e_open}")

    with src_handle as src:
        src_crs = src.crs
        crs_info = str(src_crs) if src_crs else "Non défini (WGS84 supposé)"

        # Préparer la reprojection si nécessaire
        reproject_func = None
        if src_crs:
            crs_str = str(src_crs).lower()
            if "4326" not in crs_str and "wgs" not in crs_str:
                try:
                    import pyproj
                    from shapely.ops import transform as shapely_transform
                    transformer = pyproj.Transformer.from_crs(
                        src_crs, "EPSG:4326", always_xy=True
                    )
                    reproject_func = transformer.transform
                except ImportError:
                    logger.warning("pyproj non installé — reprojection impossible")
                except Exception as e:
                    logger.warning(f"Erreur init reprojection: {e}")

        for feat in src:
            geom = shape(feat["geometry"])

            if reproject_func:
                from shapely.ops import transform as shapely_transform
                geom = shapely_transform(reproject_func, geom)

            props = {}
            raw_props = feat.get("properties", {})
            if raw_props:
                for k, v in raw_props.items():
                    # Convertir en types JSON-serializable
                    if v is not None:
                        props[k] = str(v) if not isinstance(v, (int, float, bool)) else v

            features.append({
                "type": "Feature",
                "geometry": mapping(geom),
                "properties": props,
            })

    return features, crs_info


@api_view(["POST"])
@permission_classes([permissions.IsAuthenticated])
def shapefile_preview(request):
    """Prévisualise un Shapefile uploadé : retourne GeoJSON + attributs."""
    shp_file = request.FILES.get("file")
    if not shp_file:
        return Response({"error": "Aucun fichier fourni."}, status=status.HTTP_400_BAD_REQUEST)

    tmpdir = None
    try:
        tmpdir = tempfile.mkdtemp(prefix="eyefoncier_preview_")
        safe_name = shp_file.name.replace(" ", "_")
        tmp_path = os.path.join(tmpdir, safe_name)

        with open(tmp_path, "wb") as f:
            for chunk in shp_file.chunks():
                f.write(chunk)

        features, crs_info = _open_shapefile_fiona(tmp_path)

        return Response({
            "type": "FeatureCollection",
            "features": features,
            "crs_info": crs_info,
            "count": len(features),
        })

    except ValueError as e:
        return Response({"error": str(e)}, status=400)
    except Exception as e:
        logger.error(f"Erreur shapefile preview: {e}", exc_info=True)
        return Response({"error": f"Erreur de lecture : {str(e)}"}, status=400)
    finally:
        if tmpdir:
            shutil.rmtree(tmpdir, ignore_errors=True)
