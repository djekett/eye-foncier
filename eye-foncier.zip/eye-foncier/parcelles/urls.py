from django.urls import path
from . import views

app_name = "parcelles"

urlpatterns = [
    path("", views.ParcelleListView.as_view(), name="list"),
    path("deposer/", views.parcelle_create_view, name="create"),
    path("<uuid:pk>/", views.ParcelleDetailView.as_view(), name="detail"),
    path("<uuid:pk>/modifier/", views.parcelle_edit_view, name="edit"),
    path("<uuid:pk>/supprimer/", views.ParcelleDeleteView.as_view(), name="delete"),
    path("<uuid:pk>/medias/", views.media_upload_view, name="media_upload"),
    path("<uuid:pk>/valider/", views.validate_parcelle_view, name="validate"),
]
