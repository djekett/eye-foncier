"""
Modèles GIS — EYE-FONCIER
Zone > Îlot > Parcelle avec géométries PostGIS
"""
import uuid
from django.contrib.gis.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings


class Zone(models.Model):
    """Zone géographique (Quartier / Ville)."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(_("nom de la zone"), max_length=200)
    code = models.CharField(_("code zone"), max_length=20, unique=True)
    description = models.TextField(_("description"), blank=True)
    geometry = models.PolygonField(_("géométrie"), srid=4326)
    population = models.PositiveIntegerField(_("population estimée"), null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Zone")
        verbose_name_plural = _("Zones")
        ordering = ["name"]

    def __str__(self):
        return f"{self.name} ({self.code})"


class Ilot(models.Model):
    """Îlot — groupement de lots dans une zone."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    zone = models.ForeignKey(Zone, on_delete=models.CASCADE, related_name="ilots")
    name = models.CharField(_("nom de l'îlot"), max_length=200)
    code = models.CharField(_("code îlot"), max_length=30, unique=True)
    geometry = models.MultiPolygonField(_("géométrie"), srid=4326)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Îlot")
        verbose_name_plural = _("Îlots")
        ordering = ["zone", "name"]

    def __str__(self):
        return f"Îlot {self.code} — {self.zone.name}"

    @property
    def parcelle_count(self):
        return self.parcelles.count()


class Parcelle(models.Model):
    """Parcelle — unité foncière de vente."""

    class Status(models.TextChoices):
        DISPONIBLE = "disponible", _("🟢 Disponible")
        RESERVE = "reserve", _("🟠 Réservé")
        VENDU = "vendu", _("🔴 Vendu")

    class LandType(models.TextChoices):
        RESIDENTIAL = "residentiel", _("Résidentiel")
        COMMERCIAL = "commercial", _("Commercial")
        INDUSTRIAL = "industriel", _("Industriel")
        AGRICULTURAL = "agricole", _("Agricole")
        MIXED = "mixte", _("Mixte")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="parcelles",
        verbose_name=_("propriétaire"),
    )
    ilot = models.ForeignKey(
        Ilot, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="parcelles", verbose_name=_("îlot"),
    )
    zone = models.ForeignKey(
        Zone, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="parcelles", verbose_name=_("zone"),
    )

    # Identifiants
    lot_number = models.CharField(_("numéro de lot"), max_length=50, unique=True)
    title = models.CharField(_("titre"), max_length=300)
    description = models.TextField(_("description"), blank=True)

    # Caractéristiques
    land_type = models.CharField(
        _("type de terrain"), max_length=20,
        choices=LandType.choices, default=LandType.RESIDENTIAL,
    )
    surface_m2 = models.DecimalField(
        _("surface (m²)"), max_digits=12, decimal_places=2,
    )
    price = models.DecimalField(
        _("prix (FCFA)"), max_digits=15, decimal_places=0,
    )
    price_per_m2 = models.DecimalField(
        _("prix au m² (FCFA)"), max_digits=12, decimal_places=0,
        null=True, blank=True,
    )

    # Statut
    status = models.CharField(
        _("statut"), max_length=20,
        choices=Status.choices, default=Status.DISPONIBLE,
    )
    is_validated = models.BooleanField(_("validé par géomètre"), default=False)
    validated_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL, null=True, blank=True,
        related_name="validated_parcelles",
    )
    validated_at = models.DateTimeField(null=True, blank=True)

    # Géométrie
    geometry = models.PolygonField(_("géométrie de la parcelle"), srid=4326)
    centroid = models.PointField(_("centroïde"), srid=4326, null=True, blank=True)
    address = models.CharField(_("adresse"), max_length=500, blank=True)

    # Badge de confiance
    title_holder_name = models.CharField(
        _("nom sur le titre foncier"), max_length=200, blank=True,
        help_text=_("Nom exact figurant sur le titre foncier pour vérification."),
    )
    trust_badge = models.BooleanField(
        _("badge de confiance"), default=False,
        help_text=_("Vrai si le nom du titre correspond au nom du compte."),
    )

    # Métadonnées
    views_count = models.PositiveIntegerField(_("nombre de vues"), default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Parcelle")
        verbose_name_plural = _("Parcelles")
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["status"]),
            models.Index(fields=["zone"]),
            models.Index(fields=["price"]),
            models.Index(fields=["surface_m2"]),
        ]

    def __str__(self):
        return f"Lot {self.lot_number} — {self.title}"

    def save(self, *args, **kwargs):
        # Auto-calcul du prix au m²
        if self.price and self.surface_m2 and self.surface_m2 > 0:
            self.price_per_m2 = int(self.price / self.surface_m2)
        # Auto-calcul du centroïde
        if self.geometry:
            self.centroid = self.geometry.centroid
        # Badge de confiance
        if self.title_holder_name and self.owner:
            owner_name = f"{self.owner.first_name} {self.owner.last_name}".strip().lower()
            self.trust_badge = self.title_holder_name.strip().lower() == owner_name
        super().save(*args, **kwargs)

    @property
    def status_color(self):
        colors = {
            self.Status.DISPONIBLE: "#22c55e",
            self.Status.RESERVE: "#f59e0b",
            self.Status.VENDU: "#ef4444",
        }
        return colors.get(self.status, "#6b7280")

    @property
    def main_image(self):
        img = self.medias.filter(media_type="image").first()
        return img.file.url if img else None


class ParcelleMedia(models.Model):
    """Médias associés à une parcelle (images, vidéos)."""

    class MediaType(models.TextChoices):
        IMAGE = "image", _("Image")
        VIDEO = "video", _("Vidéo")
        DRONE = "drone", _("Vue drone")
        PLAN = "plan", _("Plan")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    parcelle = models.ForeignKey(
        Parcelle, on_delete=models.CASCADE, related_name="medias",
    )
    media_type = models.CharField(
        _("type"), max_length=10, choices=MediaType.choices, default=MediaType.IMAGE,
    )
    title = models.CharField(_("titre"), max_length=200, blank=True)
    file = models.FileField(_("fichier"), upload_to="parcelles/medias/%Y/%m/")
    thumbnail = models.ImageField(
        _("miniature"), upload_to="parcelles/thumbnails/%Y/%m/", blank=True,
    )
    order = models.PositiveSmallIntegerField(_("ordre"), default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Média parcelle")
        verbose_name_plural = _("Médias parcelles")
        ordering = ["order", "-created_at"]

    def __str__(self):
        return f"{self.media_type} — {self.parcelle.lot_number}"
