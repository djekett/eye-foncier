/**
 * EYE-FONCIER — Scripts Principaux
 * Plateforme WebSIG de Transaction Foncière Sécurisée
 */

'use strict';

const EyeFoncier = {
    // ---- Configuration ----
    config: {
        apiBase: '/api/v1',
        mapCenter: [5.36, -4.008], // Abidjan
        mapZoom: 13,
        statusColors: {
            disponible: '#22c55e',
            reserve: '#f59e0b',
            vendu: '#ef4444'
        }
    },

    // ---- Initialisation ----
    init() {
        this.initTooltips();
        this.initAlertDismiss();
        this.initSmoothScroll();
        this.initFormValidation();
        console.log('EYE-FONCIER initialized');
    },

    // ---- Bootstrap Tooltips ----
    initTooltips() {
        const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        tooltips.forEach(el => new bootstrap.Tooltip(el));
    },

    // ---- Auto-dismiss alerts ----
    initAlertDismiss() {
        document.querySelectorAll('.alert-auto-dismiss').forEach(alert => {
            setTimeout(() => {
                const bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
                bsAlert.close();
            }, 5000);
        });
    },

    // ---- Smooth scroll ----
    initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
    },

    // ---- Client-side form validation ----
    initFormValidation() {
        document.querySelectorAll('form[data-validate]').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!form.checkValidity()) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                form.classList.add('was-validated');
            });
        });
    },

    // ---- API Helper ----
    async apiRequest(endpoint, options = {}) {
        const url = this.config.apiBase + endpoint;
        const defaults = {
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': this.getCSRFToken()
            }
        };
        const config = { ...defaults, ...options };
        try {
            const response = await fetch(url, config);
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    // ---- CSRF Token ----
    getCSRFToken() {
        const cookie = document.cookie.split(';')
            .find(c => c.trim().startsWith('csrftoken='));
        return cookie ? cookie.split('=')[1] : '';
    },

    // ---- Format prix FCFA ----
    formatPrice(amount) {
        return new Intl.NumberFormat('fr-FR', {
            style: 'decimal',
            maximumFractionDigits: 0
        }).format(amount) + ' FCFA';
    },

    // ---- Format surface ----
    formatSurface(m2) {
        if (m2 >= 10000) {
            return (m2 / 10000).toFixed(2) + ' ha';
        }
        return new Intl.NumberFormat('fr-FR').format(m2) + ' m²';
    },

    // ---- Leaflet helpers ----
    map: {
        /**
         * Style GeoJSON par statut
         */
        getParcelleStyle(status) {
            const color = EyeFoncier.config.statusColors[status] || '#6b7280';
            return {
                color: color,
                weight: 2.5,
                fillColor: color,
                fillOpacity: 0.25,
                opacity: 0.9
            };
        },

        /**
         * Popup HTML pour parcelle
         */
        createPopupContent(props) {
            return `
                <div style="min-width:220px;">
                    <div class="popup-title">${props.title || 'Parcelle'}</div>
                    <div class="popup-surface">
                        <i class="bi bi-arrows-fullscreen"></i> ${EyeFoncier.formatSurface(props.surface_m2)}
                        &middot; Lot ${props.lot_number || '—'}
                    </div>
                    <div class="popup-price mt-1">${EyeFoncier.formatPrice(props.price)}</div>
                    <hr style="margin:.5rem 0;">
                    <a href="/parcelles/${props.id}/" class="btn btn-success btn-sm w-100">
                        <i class="bi bi-eye me-1"></i> Voir détails
                    </a>
                </div>
            `;
        },

        /**
         * Charger les parcelles GeoJSON
         */
        async loadParcelles(mapInstance, params = {}) {
            const query = new URLSearchParams(params).toString();
            const url = `/api/v1/parcelles/geojson/${query ? '?' + query : ''}`;
            try {
                const response = await fetch(url);
                const data = await response.json();
                const layer = L.geoJSON(data, {
                    style: feature => EyeFoncier.map.getParcelleStyle(feature.properties.status),
                    onEachFeature: (feature, layer) => {
                        layer.bindPopup(
                            EyeFoncier.map.createPopupContent(feature.properties),
                            { maxWidth: 280 }
                        );
                    }
                });
                layer.addTo(mapInstance);
                return layer;
            } catch (error) {
                console.error('Error loading parcelles:', error);
                return null;
            }
        }
    },

    // ---- Notifications toast ----
    showToast(message, type = 'success') {
        const container = document.getElementById('toast-container') || (() => {
            const div = document.createElement('div');
            div.id = 'toast-container';
            div.className = 'position-fixed bottom-0 end-0 p-3';
            div.style.zIndex = '9999';
            document.body.appendChild(div);
            return div;
        })();

        const icons = {
            success: 'check-circle-fill',
            danger: 'exclamation-triangle-fill',
            warning: 'exclamation-circle-fill',
            info: 'info-circle-fill'
        };

        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi bi-${icons[type] || 'info-circle-fill'} me-1"></i> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        container.appendChild(toast);
        const bsToast = new bootstrap.Toast(toast, { delay: 4000 });
        bsToast.show();
        toast.addEventListener('hidden.bs.toast', () => toast.remove());
    }
};

// Auto-init
document.addEventListener('DOMContentLoaded', () => EyeFoncier.init());
