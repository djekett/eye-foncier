"""
Vues du coffre-fort documentaire — EYE-FONCIER
Gestion sécurisée avec watermark dynamique.
"""
import io
import hashlib
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, Http404
from django.utils import timezone
from django.conf import settings

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import Color

from .models import ParcelleDocument, DocumentAccessLog
from .forms import DocumentUploadForm
from accounts.models import AccessLog


@login_required
def document_list_view(request, parcelle_pk):
    """Liste des documents d'une parcelle."""
    from parcelles.models import Parcelle
    parcelle = get_object_or_404(Parcelle, pk=parcelle_pk)

    user = request.user
    docs = ParcelleDocument.objects.filter(parcelle=parcelle)

    # Filtrage selon le rôle
    if user.is_admin_role or user.is_geometre or parcelle.owner == user:
        pass  # Voir tout
    elif user.is_acheteur and user.is_verified:
        docs = docs.exclude(confidentiality="private")
    else:
        docs = docs.filter(confidentiality="public")

    return render(request, "documents/document_list.html", {
        "parcelle": parcelle,
        "documents": docs,
        "is_owner": parcelle.owner == request.user or request.user.is_staff,
    })


@login_required
def document_upload_view(request, parcelle_pk):
    """Upload sécurisé d'un document."""
    from parcelles.models import Parcelle
    parcelle = get_object_or_404(Parcelle, pk=parcelle_pk)

    if parcelle.owner != request.user and not request.user.is_admin_role:
        messages.error(request, "Non autorisé.")
        return redirect("parcelles:detail", pk=parcelle_pk)

    if request.method == "POST":
        form = DocumentUploadForm(request.POST, request.FILES)
        if form.is_valid():
            doc = form.save(commit=False)
            doc.parcelle = parcelle
            doc.uploaded_by = request.user

            # Calcul du hash SHA-256
            file_content = doc.file.read()
            doc.file_hash = hashlib.sha256(file_content).hexdigest()
            doc.file.seek(0)

            doc.save()

            AccessLog.objects.create(
                user=request.user,
                action=AccessLog.ActionType.UPLOAD,
                resource_type="ParcelleDocument",
                resource_id=str(doc.pk),
            )

            messages.success(request, "Document uploadé et sécurisé avec succès.")
            return redirect("documents:list", parcelle_pk=parcelle_pk)
    else:
        form = DocumentUploadForm()

    return render(request, "documents/document_upload.html", {
        "form": form,
        "parcelle": parcelle,
    })


@login_required
def document_view_watermarked(request, pk):
    """
    Consultation de document avec watermark dynamique.
    Le document n'est JAMAIS téléchargé directement.
    Il est généré en PDF avec un filigrane personnalisé.
    """
    doc = get_object_or_404(ParcelleDocument, pk=pk)
    user = request.user

    # Vérification des permissions
    if doc.confidentiality == "private" and not (user.is_admin_role or user.is_geometre):
        raise Http404("Document non accessible.")
    if doc.confidentiality == "buyer_only" and not (
        user.is_acheteur or user.is_admin_role or
        user.is_geometre or doc.parcelle.owner == user
    ):
        raise Http404("Réservé aux acheteurs vérifiés.")

    # Log de consultation
    DocumentAccessLog.objects.create(
        document=doc,
        user=user,
        ip_address=_get_ip(request),
        action="view_watermarked",
    )
    AccessLog.objects.create(
        user=user,
        action=AccessLog.ActionType.VIEW_DOC,
        resource_type="ParcelleDocument",
        resource_id=str(doc.pk),
        details={"doc_type": doc.doc_type, "parcelle": doc.parcelle.lot_number},
    )

    # Génération du PDF avec watermark
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Watermark text
    watermark_text = settings.WATERMARK_TEXT_TEMPLATE.format(
        user=user.get_full_name() or user.email,
        date=timezone.now().strftime("%d/%m/%Y à %H:%M"),
    )

    # Dessiner le watermark en diagonale
    p.saveState()
    p.setFont("Helvetica", settings.WATERMARK_FONT_SIZE)
    p.setFillColor(Color(0.8, 0.1, 0.1, alpha=settings.WATERMARK_OPACITY))
    p.translate(width / 2, height / 2)
    p.rotate(45)
    p.drawCentredString(0, 0, watermark_text)
    p.restoreState()

    # Informations du document
    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, height - 60, f"EYE-FONCIER — Document Sécurisé")

    p.setFont("Helvetica", 12)
    y = height - 100
    infos = [
        f"Type : {doc.get_doc_type_display()}",
        f"Titre : {doc.title}",
        f"Parcelle : Lot {doc.parcelle.lot_number}",
        f"Propriétaire : {doc.parcelle.owner.get_full_name()}",
        f"Vérifié : {'Oui ✓' if doc.is_verified else 'Non'}",
        f"Consulté par : {user.get_full_name()} ({user.email})",
        f"Date de consultation : {timezone.now().strftime('%d/%m/%Y %H:%M:%S')}",
        f"Hash d'intégrité : {doc.file_hash[:32]}...",
        "",
        "⚠ Ce document est protégé. Toute reproduction est tracée.",
        f"Confidentialité : {doc.get_confidentiality_display()}",
    ]
    for info in infos:
        p.drawString(50, y, info)
        y -= 25

    # Description
    if doc.description:
        y -= 20
        p.setFont("Helvetica-Oblique", 10)
        p.drawString(50, y, f"Description : {doc.description[:200]}")

    p.showPage()
    p.save()

    buffer.seek(0)
    response = HttpResponse(buffer, content_type="application/pdf")
    response["Content-Disposition"] = f'inline; filename="doc_{doc.pk}_watermarked.pdf"'
    # Empêcher le cache
    response["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response["Pragma"] = "no-cache"
    return response


def _get_ip(request):
    x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    return x_forwarded.split(",")[0].strip() if x_forwarded else request.META.get("REMOTE_ADDR")
