from django.contrib import admin
from .models import ParcelleDocument, DocumentAccessLog


@admin.register(ParcelleDocument)
class ParcelleDocumentAdmin(admin.ModelAdmin):
    list_display = [
        "title", "doc_type", "parcelle", "uploaded_by",
        "confidentiality", "is_verified", "created_at",
    ]
    list_filter = ["doc_type", "confidentiality", "is_verified"]
    search_fields = ["title", "parcelle__lot_number"]
    readonly_fields = ["file_hash", "created_at", "updated_at"]


@admin.register(DocumentAccessLog)
class DocumentAccessLogAdmin(admin.ModelAdmin):
    list_display = ["document", "user", "action", "ip_address", "timestamp"]
    list_filter = ["action"]
    readonly_fields = ["id", "document", "user", "ip_address", "action", "timestamp"]
    date_hierarchy = "timestamp"
