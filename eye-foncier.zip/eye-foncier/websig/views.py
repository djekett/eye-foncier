"""Vues WebSIG — Carte interactive et page d'accueil."""
from django.shortcuts import render
from parcelles.models import Parcelle, Zone


def home_view(request):
    """Page d'accueil."""
    context = {
        "total_parcelles": Parcelle.objects.filter(is_validated=True).count(),
        "available_parcelles": Parcelle.objects.filter(
            is_validated=True, status="disponible"
        ).count(),
        "total_zones": Zone.objects.count(),
        "recent_parcelles": Parcelle.objects.filter(
            is_validated=True, status="disponible"
        ).select_related("zone", "owner")[:6],
    }
    return render(request, "websig/home.html", context)


def map_view(request):
    """Vue carte interactive principale.

    Paramètres GET optionnels :
      • focus=<uuid>  → zoom automatique sur cette parcelle au chargement
    """
    zones = Zone.objects.all()

    # ID de parcelle à focaliser (provient de la redirection après création)
    focus_id = request.GET.get("focus", "")

    context = {
        "zones": zones,
        "default_lat": 5.3600,
        "default_lng": -4.0083,
        "default_zoom": 12,
        "is_authenticated": request.user.is_authenticated,
        "is_superuser": request.user.is_superuser if request.user.is_authenticated else False,
        "focus_parcelle_id": focus_id,
    }
    return render(request, "websig/map.html", context)
