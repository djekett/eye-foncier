"""Sérialiseurs API pour les comptes."""
from rest_framework import serializers
from .models import User, Profile


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ["avatar", "bio", "city", "country", "trust_score", "total_sales", "kyc_status"]
        read_only_fields = ["trust_score", "total_sales", "kyc_status"]


class UserPublicSerializer(serializers.ModelSerializer):
    """Infos publiques d'un utilisateur (vendeur)."""
    profile = ProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = ["id", "username", "first_name", "role", "is_verified", "profile"]


class UserPrivateSerializer(serializers.ModelSerializer):
    """Infos complètes (acheteur qualifié)."""
    profile = ProfileSerializer(read_only=True)

    class Meta:
        model = User
        fields = [
            "id", "username", "email", "first_name", "last_name",
            "phone", "role", "is_verified", "created_at", "profile",
        ]
        read_only_fields = ["id", "email", "role", "is_verified", "created_at"]


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=10)

    class Meta:
        model = User
        fields = ["email", "username", "first_name", "last_name", "phone", "role", "password"]

    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        return user
