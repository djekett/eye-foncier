"""
Modèles Comptes & Profils — EYE-FONCIER
"""
import uuid
from django.contrib.auth.models import AbstractUser
from django.contrib.gis.db import models
from django.utils.translation import gettext_lazy as _


class User(AbstractUser):
    """Utilisateur personnalisé avec rôle intégré."""

    class Role(models.TextChoices):
        VISITEUR = "visiteur", _("Visiteur")
        ACHETEUR = "acheteur", _("Acheteur")
        VENDEUR = "vendeur", _("Vendeur")
        GEOMETRE = "geometre", _("Géomètre / Validateur")
        ADMIN = "admin", _("Administrateur")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(_("adresse email"), unique=True)
    role = models.CharField(
        _("rôle"), max_length=20, choices=Role.choices, default=Role.VISITEUR
    )
    phone = models.CharField(_("téléphone"), max_length=20, blank=True)
    is_verified = models.BooleanField(_("compte vérifié"), default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username", "first_name", "last_name"]

    class Meta:
        verbose_name = _("Utilisateur")
        verbose_name_plural = _("Utilisateurs")
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.get_full_name()} ({self.role})"

    @property
    def is_acheteur(self):
        return self.role == self.Role.ACHETEUR

    @property
    def is_vendeur(self):
        return self.role == self.Role.VENDEUR

    @property
    def is_geometre(self):
        return self.role == self.Role.GEOMETRE

    @property
    def is_admin_role(self):
        return self.role == self.Role.ADMIN or self.is_staff or self.is_superuser


class Profile(models.Model):
    """Extension du profil utilisateur."""

    class KYCStatus(models.TextChoices):
        PENDING = "pending", _("En attente")
        SUBMITTED = "submitted", _("Soumis")
        VERIFIED = "verified", _("Vérifié")
        REJECTED = "rejected", _("Rejeté")

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    avatar = models.ImageField(
        _("photo de profil"), upload_to="avatars/%Y/%m/", blank=True
    )
    bio = models.TextField(_("biographie"), blank=True, max_length=500)
    address = models.CharField(_("adresse"), max_length=255, blank=True)
    city = models.CharField(_("ville"), max_length=100, blank=True)
    country = models.CharField(_("pays"), max_length=100, default="Côte d'Ivoire")

    # KYC (Know Your Customer)
    id_document = models.FileField(
        _("pièce d'identité"), upload_to="documents/kyc/%Y/%m/", blank=True
    )
    kyc_status = models.CharField(
        _("statut KYC"), max_length=20, choices=KYCStatus.choices, default=KYCStatus.PENDING
    )

    # Stats vendeur
    trust_score = models.DecimalField(
        _("score de confiance"), max_digits=3, decimal_places=1, default=0.0
    )
    total_sales = models.PositiveIntegerField(_("ventes totales"), default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Profil")
        verbose_name_plural = _("Profils")

    def __str__(self):
        return f"Profil de {self.user.get_full_name()}"

    @property
    def is_kyc_verified(self):
        return self.kyc_status == self.KYCStatus.VERIFIED


class AccessLog(models.Model):
    """Journal d'audit : qui a fait quoi et quand."""

    class ActionType(models.TextChoices):
        LOGIN = "login", _("Connexion")
        LOGOUT = "logout", _("Déconnexion")
        VIEW_DOC = "view_doc", _("Consultation document")
        VIEW_PARCELLE = "view_parcelle", _("Consultation parcelle")
        DOWNLOAD = "download", _("Téléchargement")
        RESERVATION = "reservation", _("Réservation")
        UPLOAD = "upload", _("Upload")
        UPDATE = "update", _("Modification")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name="access_logs"
    )
    action = models.CharField(_("action"), max_length=30, choices=ActionType.choices)
    resource_type = models.CharField(_("type ressource"), max_length=100, blank=True)
    resource_id = models.CharField(_("ID ressource"), max_length=255, blank=True)
    ip_address = models.GenericIPAddressField(_("adresse IP"), null=True, blank=True)
    user_agent = models.TextField(_("user agent"), blank=True)
    details = models.JSONField(_("détails"), default=dict, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        verbose_name = _("Log d'accès")
        verbose_name_plural = _("Logs d'accès")
        ordering = ["-timestamp"]
        indexes = [
            models.Index(fields=["user", "-timestamp"]),
            models.Index(fields=["action", "-timestamp"]),
        ]

    def __str__(self):
        return f"[{self.timestamp:%Y-%m-%d %H:%M}] {self.user} — {self.action}"


class CertificationRequest(models.Model):
    """Demande de certification / Badge de Confiance.

    Workflow : pending → scheduled → approved / rejected
    Types :
      • standard    — Upload pièces (gratuit)
      • visio       — Visio-vérification 15min (5 000 FCFA)
      • premium     — Visite terrain par géomètre (25 000 FCFA)
    """

    class CertType(models.TextChoices):
        STANDARD = "standard", _("Standard — Upload de pièces")
        VISIO = "visio", _("Visio-Vérification (15min)")
        PREMIUM = "premium", _("Premium — Visite terrain")

    class Status(models.TextChoices):
        PENDING = "pending", _("En attente")
        SCHEDULED = "scheduled", _("RDV programmé")
        IN_REVIEW = "in_review", _("En cours d'examen")
        APPROVED = "approved", _("Approuvé")
        REJECTED = "rejected", _("Rejeté")

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name="certification_requests",
    )
    cert_type = models.CharField(
        _("type de certification"), max_length=20,
        choices=CertType.choices, default=CertType.STANDARD,
    )
    status = models.CharField(
        _("statut"), max_length=20,
        choices=Status.choices, default=Status.PENDING,
    )
    message = models.TextField(_("message du demandeur"), blank=True)
    preferred_date = models.CharField(
        _("date souhaitée"), max_length=100, blank=True,
        help_text=_("Date/créneau préféré pour la visio ou visite."),
    )
    admin_notes = models.TextField(_("notes admin"), blank=True)
    scheduled_at = models.DateTimeField(_("RDV programmé"), null=True, blank=True)
    reviewed_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="reviewed_certifications",
    )

    # Caution vendeur premium
    caution_amount = models.DecimalField(
        _("caution déposée (FCFA)"), max_digits=10, decimal_places=0,
        null=True, blank=True,
    )
    caution_paid = models.BooleanField(_("caution payée"), default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = _("Demande de certification")
        verbose_name_plural = _("Demandes de certification")
        ordering = ["-created_at"]

    def __str__(self):
        return f"Cert-{self.user.username} ({self.cert_type}) — {self.status}"
