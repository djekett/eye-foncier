from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Profile, AccessLog, CertificationRequest


class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = "Profil"
    fk_name = "user"


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    inlines = [ProfileInline]
    list_display = ["email", "username", "first_name", "last_name", "role", "is_verified", "created_at"]
    list_filter = ["role", "is_verified", "is_active", "created_at"]
    search_fields = ["email", "username", "first_name", "last_name"]
    ordering = ["-created_at"]
    fieldsets = BaseUserAdmin.fieldsets + (
        ("EYE-FONCIER", {"fields": ("role", "phone", "is_verified")}),
    )


@admin.register(AccessLog)
class AccessLogAdmin(admin.ModelAdmin):
    list_display = ["timestamp", "user", "action", "resource_type", "ip_address"]
    list_filter = ["action", "timestamp"]
    search_fields = ["user__email", "resource_type", "ip_address"]
    readonly_fields = [
        "id", "user", "action", "resource_type", "resource_id",
        "ip_address", "user_agent", "details", "timestamp",
    ]
    date_hierarchy = "timestamp"


@admin.register(CertificationRequest)
class CertificationRequestAdmin(admin.ModelAdmin):
    list_display = ["user", "cert_type", "status", "caution_paid", "created_at"]
    list_filter = ["cert_type", "status", "caution_paid"]
    search_fields = ["user__email", "user__first_name", "user__last_name"]
    readonly_fields = ["id", "created_at", "updated_at"]
    list_editable = ["status"]
    date_hierarchy = "created_at"
