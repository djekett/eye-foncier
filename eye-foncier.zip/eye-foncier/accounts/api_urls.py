from django.urls import path
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from . import api_views

urlpatterns = [
    path("token/", TokenObtainPairView.as_view(), name="token_obtain"),
    path("token/refresh/", TokenRefreshView.as_view(), name="token_refresh"),
    path("register/", api_views.RegisterAPIView.as_view(), name="api_register"),
    path("me/", api_views.CurrentUserAPIView.as_view(), name="api_me"),
]
