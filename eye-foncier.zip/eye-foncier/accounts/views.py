"""Vues de gestion des comptes utilisateurs — EYE-FONCIER."""
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib import messages
from django.views.generic import DetailView, ListView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import Http404, JsonResponse
from django.utils import timezone

from .models import User, Profile, AccessLog, CertificationRequest
from .forms import (
    CustomUserCreationForm,
    CustomLoginForm,
    ProfileUpdateForm,
    UserUpdateForm,
)


# ─── Inscription ────────────────────────────────────────
def register_view(request):
    if request.user.is_authenticated:
        return redirect("accounts:dashboard")
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user, backend="accounts.backends.EmailBackend")
            messages.success(request, f"Bienvenue {user.first_name} ! Compte créé avec succès.")
            AccessLog.objects.create(
                user=user, action=AccessLog.ActionType.LOGIN,
                ip_address=_get_ip(request),
                user_agent=request.META.get("HTTP_USER_AGENT", ""),
                details={"method": "register"},
            )
            return redirect("accounts:dashboard")
    else:
        form = CustomUserCreationForm()
    return render(request, "accounts/register.html", {"form": form})


# ─── Connexion ──────────────────────────────────────────
class CustomLoginView(LoginView):
    form_class = CustomLoginForm
    template_name = "accounts/login.html"
    redirect_authenticated_user = True

    def form_valid(self, form):
        response = super().form_valid(form)
        AccessLog.objects.create(
            user=self.request.user, action=AccessLog.ActionType.LOGIN,
            ip_address=_get_ip(self.request),
            user_agent=self.request.META.get("HTTP_USER_AGENT", ""),
        )
        messages.success(self.request, f"Bon retour, {self.request.user.first_name} !")
        return response


class CustomLogoutView(LogoutView):
    next_page = "websig:home"


# ─── Profil (mon propre profil) ─────────────────────────
@login_required
def profile_view(request):
    # Garantir que le Profile existe (auto-create si signal raté)
    profile, _ = Profile.objects.get_or_create(user=request.user)
    if request.method == "POST":
        user_form = UserUpdateForm(request.POST, instance=request.user)
        profile_form = ProfileUpdateForm(request.POST, request.FILES, instance=profile)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, "Profil mis à jour avec succès.")
            return redirect("accounts:profile")
    else:
        user_form = UserUpdateForm(instance=request.user)
        profile_form = ProfileUpdateForm(instance=profile)

    # Certification en cours ?
    certification = CertificationRequest.objects.filter(user=request.user).order_by("-created_at").first()
    return render(request, "accounts/profile.html", {
        "user_form": user_form,
        "profile_form": profile_form,
        "certification": certification,
    })


# ─── Profil public (tous les rôles, pas seulement vendeur) ─────
class SellerProfileView(DetailView):
    """Profil public d'un utilisateur.

    BUG FIX : l'ancienne version filtrait role=VENDEUR, ce qui provoquait
    un 404 pour les superusers et les géomètres. Maintenant tous les
    utilisateurs ont un profil public accessible.
    """
    model = User
    template_name = "accounts/seller_profile.html"
    context_object_name = "seller"

    def get_queryset(self):
        # Tous les utilisateurs actifs (plus de filtre par rôle)
        return User.objects.filter(is_active=True)

    def get_object(self, queryset=None):
        """Surcharge pour garantir que le profil existe."""
        obj = super().get_object(queryset)
        # Auto-créer le Profile s'il n'existe pas
        Profile.objects.get_or_create(user=obj)
        return obj

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        seller = self.object
        user = self.request.user

        # Parcelles du vendeur
        parcelles_qs = seller.parcelles.filter(is_validated=True)
        ctx["parcelles"] = parcelles_qs
        ctx["parcelles_count"] = parcelles_qs.count()

        # Montrer les infos privées uniquement aux connectés
        ctx["show_private"] = user.is_authenticated

        # Certification
        cert = CertificationRequest.objects.filter(
            user=seller, status="approved"
        ).first()
        ctx["is_certified"] = cert is not None

        return ctx


# ─── Tableau de bord ────────────────────────────────────
@login_required
def dashboard_view(request):
    user = request.user
    from parcelles.models import Parcelle
    from transactions.models import Transaction

    if user.is_vendeur:
        parcelles_qs = user.parcelles.all()
        transactions_qs = user.sales.all()
        stats = {
            "parcelles_count": parcelles_qs.count(),
            "reservations_count": transactions_qs.filter(status="reserved").count(),
            "documents_count": sum(p.documents.count() for p in parcelles_qs[:50]),
            "transactions_count": transactions_qs.count(),
        }
        recent_parcelles = parcelles_qs[:5]
        recent_transactions = transactions_qs[:5]
    elif user.is_acheteur:
        transactions_qs = user.purchases.all()
        stats = {
            "parcelles_count": 0,
            "reservations_count": transactions_qs.filter(status="reserved").count(),
            "documents_count": 0,
            "transactions_count": transactions_qs.count(),
        }
        recent_parcelles = Parcelle.objects.filter(is_validated=True, status="disponible")[:5]
        recent_transactions = transactions_qs[:5]
    elif user.is_admin_role or user.is_geometre or user.is_superuser:
        stats = {
            "parcelles_count": Parcelle.objects.count(),
            "reservations_count": Transaction.objects.filter(status="reserved").count(),
            "documents_count": 0,
            "transactions_count": Transaction.objects.count(),
        }
        recent_parcelles = Parcelle.objects.all()[:5]
        recent_transactions = Transaction.objects.all()[:5]
    else:
        stats = {"parcelles_count": 0, "reservations_count": 0, "documents_count": 0, "transactions_count": 0}
        recent_parcelles = Parcelle.objects.filter(is_validated=True, status="disponible")[:5]
        recent_transactions = Transaction.objects.none()

    recent_logs = AccessLog.objects.filter(user=user).order_by("-timestamp")[:10]
    if user.is_admin_role or user.is_superuser:
        recent_logs = AccessLog.objects.all().order_by("-timestamp")[:20]

    # Certification
    certification = CertificationRequest.objects.filter(user=user).order_by("-created_at").first()

    context = {
        "user": user, "stats": stats,
        "recent_parcelles": recent_parcelles,
        "recent_transactions": recent_transactions,
        "recent_logs": recent_logs,
        "certification": certification,
    }
    return render(request, "accounts/dashboard.html", context)


# ─── Certification ──────────────────────────────────────
@login_required
def certification_request_view(request):
    """Demande de certification — Badge de confiance."""
    existing = CertificationRequest.objects.filter(
        user=request.user, status__in=["pending", "scheduled"]
    ).first()

    if request.method == "POST":
        if existing:
            messages.info(request, "Vous avez déjà une demande de certification en cours.")
            return redirect("accounts:certification")

        cert_type = request.POST.get("cert_type", "standard")
        message = request.POST.get("message", "")
        preferred_date = request.POST.get("preferred_date", "")

        cert = CertificationRequest.objects.create(
            user=request.user,
            cert_type=cert_type,
            message=message,
            preferred_date=preferred_date or None,
        )
        messages.success(
            request,
            "Demande de certification soumise ! Notre équipe vous contactera "
            "sous 48h pour planifier la visio-vérification."
        )
        return redirect("accounts:certification")

    return render(request, "accounts/certification.html", {
        "existing": existing,
        "cert_types": CertificationRequest.CertType.choices,
    })


@login_required
def certification_chat_api(request):
    """API pour le chat de certification (réponses automatiques + escalade)."""
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=405)
    import json
    try:
        data = json.loads(request.body)
    except Exception:
        data = {}
    user_msg = data.get("message", "").strip()
    if not user_msg:
        return JsonResponse({"reply": "Veuillez poser votre question."})

    # Réponses automatiques par mots-clés
    lower = user_msg.lower()
    if any(w in lower for w in ["certifi", "badge", "confiance", "vérif"]):
        reply = (
            "Pour obtenir votre Badge de Confiance, nous proposons 3 options :\n\n"
            "1️⃣ **Standard** — Upload de vos pièces (CNI + titre foncier)\n"
            "2️⃣ **Visio-Vérification** — Appel vidéo de 15min avec un agent\n"
            "3️⃣ **Premium** — Visite terrain par un géomètre EYE-Foncier\n\n"
            "Cliquez sur 'Demander la certification' ci-dessus pour démarrer !"
        )
    elif any(w in lower for w in ["prix", "coût", "tarif", "combien", "paiement"]):
        reply = (
            "💰 Nos tarifs de certification :\n\n"
            "• Standard : Gratuit\n"
            "• Visio-Vérification : 5 000 FCFA\n"
            "• Premium (terrain) : 25 000 FCFA\n\n"
            "La caution de garantie vendeur est de 50 000 FCFA (remboursable)."
        )
    elif any(w in lower for w in ["rdv", "rendez", "date", "quand", "disponib"]):
        reply = (
            "📅 Nos créneaux de visio-vérification :\n\n"
            "Lundi - Vendredi : 9h - 17h\n"
            "Samedi : 9h - 12h\n\n"
            "Indiquez votre date préférée dans le formulaire de certification."
        )
    elif any(w in lower for w in ["humain", "agent", "opérateur", "aide", "parler"]):
        reply = (
            "🧑‍💼 Un agent va prendre le relais !\n\n"
            "📧 certification@eye-foncier.ci\n"
            "📞 +225 07 07 07 07 07\n"
            "📍 Abidjan, Cocody Riviera Palmeraie\n\n"
            "Temps de réponse moyen : 2h en jour ouvré."
        )
    else:
        reply = (
            "Merci pour votre message ! Je suis l'assistant EYE-Foncier.\n\n"
            "Je peux vous aider avec :\n"
            "• La **certification** de votre compte\n"
            "• Les **tarifs** et modalités\n"
            "• La prise de **rendez-vous**\n\n"
            "Tapez un de ces sujets ou demandez à parler à un **agent humain**."
        )

    return JsonResponse({"reply": reply})


# ─── Admin : Logs ──────────────────────────────────────
class AccessLogListView(LoginRequiredMixin, UserPassesTestMixin, ListView):
    model = AccessLog
    template_name = "accounts/access_logs.html"
    context_object_name = "logs"
    paginate_by = 50
    def test_func(self):
        return self.request.user.is_admin_role or self.request.user.is_staff


# ─── Utilitaire ────────────────────────────────────────
def _get_ip(request):
    x = request.META.get("HTTP_X_FORWARDED_FOR")
    return x.split(",")[0].strip() if x else request.META.get("REMOTE_ADDR")
