from django.urls import path
from . import views

app_name = "accounts"

urlpatterns = [
    path("inscription/", views.register_view, name="register"),
    path("connexion/", views.CustomLoginView.as_view(), name="login"),
    path("deconnexion/", views.CustomLogoutView.as_view(), name="logout"),
    path("profil/", views.profile_view, name="profile"),
    path("tableau-de-bord/", views.dashboard_view, name="dashboard"),
    path("vendeur/<uuid:pk>/", views.SellerProfileView.as_view(), name="seller_profile"),
    path("logs/", views.AccessLogListView.as_view(), name="access_logs"),
    # Certification
    path("certification/", views.certification_request_view, name="certification"),
    path("certification/chat/", views.certification_chat_api, name="certification_chat"),
]
